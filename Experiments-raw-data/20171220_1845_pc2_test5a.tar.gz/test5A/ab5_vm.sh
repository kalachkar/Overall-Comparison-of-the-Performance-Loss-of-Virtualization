#!/bin/bash
clear
echo "The script starts soon."
for i in {1..25}
	do
	echo "Round $i"
	echo "=== Round $i ===" >> abresult_vm.txt
	ab -n 1000 -c 100 -g abresult_vm_$i.tsv "http://web1.vm.os5.nl/?x" >> abresult_vm.txt
	sleep 1
	done
	vim abresult_vm.txt -c "hardcopy > abresult_vm.pdf | q"
echo "The script is finished"
