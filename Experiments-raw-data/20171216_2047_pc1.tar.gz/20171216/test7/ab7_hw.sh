#!/bin/bash
clear
echo "The script starts soon."
for i in {1..25}
	do
	echo "Round $i"
	echo "=== Round $i ===" >> abresult_hw.txt
	ab -n 100000 -c 10 -g abresult_hw_$i.tsv "http://app.hw.os5.nl/" >> abresult_hw.txt
	sleep 1
	done
	vim abresult_hw.txt -c "hardcopy > abresult_hw.pdf | q"
echo "The script is finished"
